<?php
// Verifico si la función 'view' no existe para evitar redefinirla
if (!function_exists("view")) {

    // Defino la función 'view' que carga una vista con parámetros
    function view($nombreVista, $params = []) // Asegúrate de que $params tenga un valor por defecto
    {
        // Verifico si el nombre de la vista está vacío
        if (empty($nombreVista)) {
            die("Error: El nombre de la vista no puede estar vacío.");
        }

        // Recorro los parámetros y creo variables dinámicas con sus nombres y valores
        foreach ($params as $key => $param) {
            $$key = $param; // Crea variables dinámicas
        }

        // Divido el nombre de la vista en partes utilizando el punto como separador
        $vista = explode('.', $nombreVista);

        // Verifico que el archivo de la vista exista antes de incluirlo
        $rutaVista = "./views/{$vista[0]}/{$vista[1]}.php";
        if (file_exists($rutaVista)) {
            include_once $rutaVista; // Incluyo el archivo PHP correspondiente a la vista
        } else {
            die("Error: La vista no fue encontrada: " . htmlspecialchars($rutaVista));
        }
    }
}
?>