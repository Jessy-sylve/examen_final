<?php
class DB extends PDO {
    // Constructor de la clase DB, que extiende la clase PDO para manejar la base de datos
    public function __construct() {
        // Defino el Data Source Name (DSN) para conectarme a la base de datos MySQL
        $dsn = 'mysql:host=localhost;dbname=proyecto-libros;charset=utf8mb4';

        try {
            // Llamo al constructor de la clase PDO, pasando el DSN y las credenciales (usuario 'root' y contraseña vacía)
            parent::__construct($dsn, 'root', '');

            // Establezco el modo de error a excepciones
            $this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // Establezco el modo de emulación de consultas a falso
            $this->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        } catch (PDOException $e) {
            // Manejo de errores: mostrar un mensaje y detener la ejecución
            die("Error de conexión: " . $e->getMessage());
        }
    }
}
?>