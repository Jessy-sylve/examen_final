<?php
session_start(); // Iniciar sesión al principio

// Incluir los archivos necesarios para el funcionamiento
include_once "../models/DB.php";       // Archivo que maneja la conexión a la base de datos
include_once "../models/Libro.php";    // Archivo que define el modelo 'Libro' para operaciones CRUD

// Obtener todos los libros para mostrarlos en la tabla
$libros = Libro::all(); // Obtener todos los libros desde el modelo

// Manejo de operaciones CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Crear o actualizar un libro
    $libro = new Libro();
    $libro->titulo = $_POST['titulo'];
    $libro->autor = $_POST['autor'];
    $libro->anio_publicacion = $_POST['anio_publicacion'];
    $libro->genero = $_POST['genero'];
    $libro->isbn = $_POST['isbn'];

    if (!empty($_POST['libro-id'])) {
        $libro->id = $_POST['libro-id']; // Editar libro existente
    }

    $libro->save(); // Guardar el libro (insertar o actualizar)

    header("Location: index.php"); // Redirigir a la página principal
    exit();
} elseif (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    // Eliminar un libro
    $libro = Libro::find($_GET['id']);
    if ($libro) {
        $libro->remove();
    }
    header("Location: index.php"); // Redirigir a la página principal
    exit();
} elseif (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    // Cargar datos del libro para editar
    $libro = Libro::find($_GET['id']);
} else {
    // Si no es una acción de editar, limpiar la variable libro
    $libro = null;
}

// Guardar la información en la sesión para usarla en la vista
$_SESSION['libros'] = $libros;
$_SESSION['libro'] = isset($libro) ? $libro : null;