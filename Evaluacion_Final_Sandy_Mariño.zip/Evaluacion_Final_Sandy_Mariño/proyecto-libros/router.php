<?php
// Incluir los archivos necesarios para el funcionamiento del enrutador
include_once "utils/defaults.php"; // Archivo que define funciones útiles, como 'view'
include_once "models/DB.php";       // Archivo que maneja la conexión a la base de datos
include_once "models/Libro.php";    // Archivo que define el modelo 'Libro' para operaciones CRUD

// Obtener los parámetros de la URL pasados por la reescritura de URL
$controller = isset($_GET['controller']) ? $_GET['controller'] : 'libros'; // Controlador por defecto
$action = isset($_GET['action']) ? $_GET['action'] : 'index'; // Acción por defecto
$id = isset($_GET['id']) ? $_GET['id'] : null; // ID por defecto

// Construir el nombre de la clase del controlador basado en el nombre del controlador en la URL
$ctrlName = ucfirst($controller) . "Controller"; // Convertir el nombre del controlador a formato de clase (por ejemplo, 'LibrosController')

// Verificar si el archivo del controlador existe antes de incluirlo
$controllerFile = "./controllers/$ctrlName.php";
if (file_exists($controllerFile)) {
    include $controllerFile; // Incluye el archivo del controlador
} else {
    die("Controlador no encontrado: " . htmlspecialchars($ctrlName));
}

// Verificar si la clase del controlador existe
if (class_exists($ctrlName)) {
    $ctrl = new $ctrlName; // Instanciar el controlador
    
    // Verificar si la acción existe en el controlador
    if (method_exists($ctrl, $action)) {
        $ctrl->{$action}($id); // Llamar al método de acción del controlador, pasando el ID si está presente
    } else {
        die("Acción no encontrada: " . htmlspecialchars($action));
    }
} else {
    die("Clase no encontrada: " . htmlspecialchars($ctrlName));
}