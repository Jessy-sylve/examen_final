// Aquí establezco la URL base de la API que utilizo para realizar todas las operaciones CRUD con los libros.
const API_URL = 'https://api.ejemplo.com/libros';

// Función para obtener todos los libros
async function obtenerLibros() {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error('Error al obtener los libros');
    }
    const data = await response.json(); // Convierto la respuesta en formato JSON.
    console.log('Libros obtenidos:', data);
    // Aquí puedes actualizar el DOM con los datos obtenidos.
  } catch (error) {
    console.error('Error al obtener los libros:', error);
  }
}

// Función para obtener un libro por su ID
async function obtenerLibro(id) {
  try {
    const response = await fetch(`${API_URL}/${id}`);
    if (!response.ok) {
      throw new Error('Error al obtener el libro');
    }
    const data = await response.json(); // Convierto la respuesta en JSON
    console.log('Libro obtenido:', data);
    // Aquí puedes actualizar el DOM con el libro obtenido.
  } catch (error) {
    console.error('Error al obtener el libro:', error);
  }
}

// Función para agregar un nuevo libro
async function agregarLibro(datos) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(datos),
    });
    if (!response.ok) {
      throw new Error('Error al agregar el libro');
    }
    const data = await response.json(); // Convierto la respuesta en JSON si todo salió bien
    console.log('Libro agregado con éxito:', data);
    // Actualiza el DOM o llama a obtenerLibros() para refrescar la lista
    obtenerLibros();
  } catch (error) {
    console.error('Error al agregar el libro:', error);
  }
}

// Función para actualizar un libro por su ID
async function actualizarLibro(id, datos) {
  try {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(datos),
    });
    if (!response.ok) {
      throw new Error('Error en la actualización');
    }
    const data = await response.json(); // Convierto la respuesta en JSON
    console.log('Libro actualizado con éxito:', data);
    // Actualiza el DOM o llama a obtenerLibros() para refrescar la lista
    obtenerLibros();
  } catch (error) {
    console.error('Error al actualizar el libro:', error);
  }
}

// Función para eliminar un libro por su ID
async function eliminarLibro(id) {
  try {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'DELETE',
    });
    if (!response.ok) {
      throw new Error('Error al eliminar el libro');
    }
    console.log('Libro eliminado con éxito');
    // Actualiza el DOM o llama a obtenerLibros() para refrescar la lista
    obtenerLibros();
  } catch (error) {
    console.error('Error al eliminar el libro:', error);
  }
}

// Ejemplo de uso
// Obtener todos los libros
obtenerLibros();

// Obtener un libro específico (por ejemplo, con ID 1)
obtenerLibro(1);

// Agregar un nuevo libro
agregarLibro({
  titulo: 'Nuevo Libro',
  autor: 'Autor Ejemplo',
  anio_publicacion: 2023,
  genero: 'Ficción',
  isbn: '1234567890'
});

// Actualizar un libro existente (por ejemplo, con ID 1)
actualizarLibro(1, {
  titulo: 'Libro Actualizado',
  autor: 'Autor Actualizado',
  anio_publicacion: 2023,
  genero: 'No Ficción',
  isbn: '0987654321'
});

// Eliminar un libro (por ejemplo, con ID 1)
eliminarLibro(1);