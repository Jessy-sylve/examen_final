<!DOCTYPE html>
<!-- Nombre: SANDY JESSENIA MARIÑO MORETA -->
<!-- Asignatura: APLICACIÓN TECNOLOGÍAS WEB NRC: 17707 -->
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluación Final - Parte práctica</title>
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet"> <!-- Enlace a Google Fonts -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 10px 20px;
            background-color: #f1e4f4; /* Lila pastel claro */
            color: #4b2c4a; /* Color de texto oscuro */
        }
        h1 {
            font-family: 'Lobster', cursive;
            font-size: 3em;
            text-align: center;
            margin: 0;
            line-height: 1.2;
            color: #d48db9; /* Rosa pastel */
        }
        .name {
            font-family: Arial, sans-serif;
            font-size: 1.5em;
            text-align: center;
            margin: 20px 0;
            color: #6f4c7a; /* Lila pastel más oscuro */
        }
        form {
            margin: 0 auto;
            max-width: 600px;
            padding: 20px;
            background-color: rgba(255, 182, 193, 0.9); /* Rosa pastel */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            color: #4b2c4a; /* Color de texto oscuro */
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input[type="text"], input[type="number"] {
            width: calc(100% - 20px);
            padding: 15px;
            margin-bottom: 15px;
            border: 1px solid #d48db9; /* Rosa pastel */
            background-color: #fff;
            color: #4b2c4a; /* Color de texto oscuro */
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            max-width: 200px;
            box-sizing: border-box;
            margin: 20px auto 0;
            display: block;
            transition: background-color 0.3s, transform 0.3s;
            background-color: #6f4c7a; /* Lila pastel */
        }
        button:hover {
            background-color: #d48db9; /* Rosa pastel */
            transform: scale(1.05);
        }
        .btn-edit, .btn-delete {
            background-color: #4b2c4a; /* Color oscuro */
            margin: 0 10px;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }
        .btn-edit:hover, .btn-delete:hover {
            background-color: #d48db9; /* Rosa pastel */
            transform: scale(1.05);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        th, td {
            border: 1px solid #d48db9; /* Rosa pastel */
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #6f4c7a; /* Lila pastel oscuro */
            color: #fff;
        }
    </style>
</head>
<body>
    <h1>
       Gestión De Libros
    </h1>
    <p class="name">Nombre: Sandy Mariño</p>

    <form id="libro-form">
        <input type="hidden" id="libro-id">
        <input type="text" id="titulo" placeholder="Título" required>
        <input type="text" id="autor" placeholder="Autor" required>
        <input type="number" id="anio_publicacion" placeholder="Año de publicación" required>
        <input type="text" id="genero" placeholder="Género" required>
        <input type="text" id="isbn" placeholder="ISBN" required>
        <button id="guardar-libro" type="submit">Guardar Libro</button>
    </form>

    <table id="libros-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Autor</th>
                <th>Año</th>
                <th>Género</th>
                <th>ISBN</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if (isset($libros) && is_array($libros))
            foreach ($libros as $libro): ?>
            <tr>
                <td><?php echo $libro->id; ?></td>
                <td><?php echo $libro->titulo; ?></td>
                <td><?php echo $libro->autor; ?></td>
                <td><?php echo $libro->anio_publicacion; ?></td>
                <td><?php echo $libro->genero; ?></td>
                <td><?php echo $libro->isbn; ?></td>
                <td>
                    <button class="btn-edit" onclick="editarLibro(<?php echo $libro->id; ?>)">Editar</button>
                    <button class="btn-delete" onclick="eliminarLibro(<?php echo $libro->id; ?>)">Eliminar</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <script>
        // Función para manejar el envío del formulario
        document.getElementById('libro-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            const id = document.getElementById('libro-id').value;
            const titulo = document.getElementById('titulo').value;
            const autor = document.getElementById('autor').value;
            const anio_publicacion = document.getElementById('anio_publicacion').value;
            const genero = document.getElementById('genero').value;
            const isbn = document.getElementById('isbn').value;

            const libro = {
                titulo: titulo,
                autor: autor,
                anio_publicacion: anio_publicacion,
                genero: genero,
                isbn: isbn
            };

            let url = '/proyecto-libros/libros/create';
            let method = 'POST';

            if (id) {
                libro.id = id;
                url = '/proyecto-libros/libros/update/' + id;
                method = 'PUT';
            }

            try {
                const response = await fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(libro)
                });
                const data = await response.json();
                if (data) {
                    // Recargar la página para ver los cambios
                    window.location.reload();
                }
            } catch (error) {
                console.error('Error al guardar el libro:', error);
            }
        });

        // Función para editar un libro
        async function editarLibro(id) {
            try {
                const response = await fetch(`/proyecto-libros/libros/find/${id}`);
                const data = await response.json();
                document.getElementById('libro-id').value = data.id;
                document.getElementById('titulo').value = data.titulo;
                document.getElementById('autor').value = data.autor;
                document.getElementById('anio_publicacion').value = data.anio_publicacion;
                document.getElementById('genero').value = data.genero;
                document.getElementById('isbn').value = data.isbn;
            } catch (error) {
                console.error('Error al obtener el libro:', error);
            }
        }
        
        // Función para eliminar un libro
        async function eliminarLibro(id) {
            if (confirm('¿Estás seguro de que quieres eliminar este libro?')) {
                try {
                    const response = await fetch(`/proyecto-libros/libros/delete/${id}`, {
                        method: 'DELETE'
                    });
                    const data = await response.json();
                    if (data) {
                        // Recargar la página para ver los cambios
                        window.location.reload();
                    }
                } catch (error) {
                    console.error('Error al eliminar el libro:', error);
                }
            }
        }
    </script>
</body>
</html>